<template>
    <div>
        <CustomDirectivas/>
    </div>
</template>

<script setup>
import CustomDirectivas from '../components/CustomDirectivas.vue'

</script>

<style lang="scss" scoped>

</style>