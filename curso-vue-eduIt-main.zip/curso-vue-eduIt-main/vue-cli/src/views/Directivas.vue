<template>
    <div>
       <Directivas/>
    </div>
</template>

<script setup>
import Directivas from '../components/Directivas.vue'

</script>

<style lang="scss" scoped>

</style>