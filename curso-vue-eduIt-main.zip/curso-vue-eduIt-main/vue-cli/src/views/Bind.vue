<template>
    <div>
        <Bind/>
    </div>
</template>

<script setup>

import Bind from '../components/Bind.vue'

</script>

<style lang="scss" scoped>

</style>