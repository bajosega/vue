<template>
    <div>
       <Interpolacion/>
    </div>
</template>

<script setup>
import Interpolacion from '../components/Interpolacion.vue'

</script>

<style lang="scss" scoped>

</style>