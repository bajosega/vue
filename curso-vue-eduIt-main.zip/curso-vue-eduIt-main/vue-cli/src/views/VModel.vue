<template>
    <div>
       <VModel/>
    </div>
</template>

<script setup>
import VModel from '../components/VModel.vue'
</script>

<style lang="scss" scoped>

</style>