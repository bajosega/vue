<template>
    <div>
       <Eventos/>
    </div>
</template>

<script setup>
import Eventos from '../components/Eventos.vue'
</script>

<style lang="scss" scoped>

</style>