<template>
    <div class="max-w-sm rounded overflow-hidden shadow-xl">
        <div class="px-6 py-4 text-left">
            <div class="font-bold text-xl mb-2" >
                Maria Martinez
            </div>
            <p class="text-gray-700 text-base" >
                <slot> Desarrolladora de software </slot>
            </p>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>